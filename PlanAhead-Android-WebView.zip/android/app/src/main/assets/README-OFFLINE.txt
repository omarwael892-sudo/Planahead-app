Place your HTML file here as index.html.

Important: the supplied HTML loads Tailwind CSS and Lucide icons from online CDNs.
The app can open locally, but the styling/icons require internet until those libraries
are downloaded and their script URLs are changed to local asset paths. The page's
localStorage data is stored by the WebView on this device.
